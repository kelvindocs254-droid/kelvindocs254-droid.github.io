import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post('/api/chat', async (req, res) => {
    try {
      const { history } = req.body;
      
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: 'Missing API Key' });
      }

      const ai = new GoogleGenAI({ apiKey });
      
      const formattedHistory = (history || [])
        .map((msg: any) => ({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: [{ text: msg.text }]
        }));

      // The last element is the newest user message
      const latestMessage = formattedHistory.pop();
      if (!latestMessage) {
        return res.json({ response: 'Empty chat' });
      }
      
      const chatOptions = {
        model: 'gemini-3.5-flash',
        history: formattedHistory,
        config: {
          systemInstruction: `You are 'KEMU AI Assistant', the AI Concierge for KEMU Cloud Solutions. 
      We are an applications development agency specializing in web and mobile solutions, cloud infrastructure, and data analytics.
      
      Tone: Professional, helpful, slightly tech-forward, and competent. Use simple emojis occasionally (e.g. 💻, ☁️, 🚀, 💡).
      
      Key Info:
      - Services: Web Apps, Mobile Apps, Cloud Infrastructure, Custom APIs, Data Analytics.
      - Hotline: 0758872861
      - Philosophy: Agile development, scalable enterprise architecture, zero trust security.
      
      Keep responses short (under 50 words) and professional. Provide helpful guidance about our software services.`
        }
      };

      const chat = ai.chats.create(chatOptions);
      
      const response = await chat.sendMessage({ message: latestMessage.parts[0].text });

      res.json({ response: response.text });
    } catch (error) {
      console.error('Chat error:', error);
      res.status(500).json({ error: 'Failed to generate response' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
