/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { ChatMessage } from '../types';

export const sendMessageToGemini = async (input: string, history: ChatMessage[] = []): Promise<string> => {
  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ history })
    });
    
    if (!response.ok) {
      throw new Error('API request failed');
    }
    
    const data = await response.json();
    return data.response || "Transmission interrupted.";
  } catch (error) {
    console.error("Chat Error:", error);
    return "Signal lost. Try again later.";
  }
};