import { useEffect, useRef } from 'react';

export const useHoverSound = () => {
  const audioCtxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    // Add event listeners for mouseover on clickable elements
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('a') || target.closest('[data-hover="true"]')) {
        
        // Initialize AudioContext if not already
        if (!audioCtxRef.current) {
          audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }

        // Resume if suspended
        if (audioCtxRef.current.state === 'suspended') {
          audioCtxRef.current.resume();
        }

        if (audioCtxRef.current && audioCtxRef.current.state === 'running') {
          // Play a very subtle techy click
          const osc = audioCtxRef.current.createOscillator();
          const gain = audioCtxRef.current.createGain();
          
          osc.type = 'sine';
          osc.frequency.setValueAtTime(1200, audioCtxRef.current.currentTime);
          osc.frequency.exponentialRampToValueAtTime(1600, audioCtxRef.current.currentTime + 0.03);
          
          gain.gain.setValueAtTime(0.015, audioCtxRef.current.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, audioCtxRef.current.currentTime + 0.03);
          
          osc.connect(gain);
          gain.connect(audioCtxRef.current.destination);
          
          osc.start();
          osc.stop(audioCtxRef.current.currentTime + 0.03);
        }
      }
    };

    window.addEventListener('mouseover', handleMouseOver);
    
    // Also listen to click to ensure audio context is resumed (browsers require user interaction)
    const handleClick = () => {
      if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }
    };
    window.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('click', handleClick);
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);
};
